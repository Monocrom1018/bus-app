export const jwtConstants = {
  // rails의 mastercredentials에 있는것 같은 키를 넣어놔야 한다
  secret: 'secretKey',
};
