import { Controller } from '@nestjs/common';

@Controller('contacts')
export class ContactsController {}
