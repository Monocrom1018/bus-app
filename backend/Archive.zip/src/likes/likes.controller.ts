import { Controller } from '@nestjs/common';

@Controller('likes')
export class LikesController {}
