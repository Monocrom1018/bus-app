import { Controller } from '@nestjs/common';

@Controller('rooms')
export class RoomsController {}
