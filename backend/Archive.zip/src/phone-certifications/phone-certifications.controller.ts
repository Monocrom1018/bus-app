import { Controller } from '@nestjs/common';

@Controller('phone-certifications')
export class PhoneCertificationsController {}
