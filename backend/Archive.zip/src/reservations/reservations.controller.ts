import { Controller } from '@nestjs/common';

@Controller('reservations')
export class ReservationsController {}
