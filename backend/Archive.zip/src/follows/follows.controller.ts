import { Controller } from '@nestjs/common';

@Controller('follows')
export class FollowsController {}
