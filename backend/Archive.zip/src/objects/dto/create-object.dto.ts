export class CreateObjectDto {}
