import { Controller } from '@nestjs/common';

@Controller('images')
export class ImagesController {}
